# Youshu

[中文](#有数)

![A fictional studio tests a 30-day payment delay, then follows a September expense back to its Alipay statement.](docs/media/en/youshu-demo.gif)

[Download the English demo (MP4, 17.5 seconds)](docs/media/en/youshu-demo.mp4?raw=1)

**Turn your WeChat, Alipay, and bank statements into a personalized financial report. Youshu makes professional financial reports easy to read for small businesses and solo founders.**

v0.4.0 · No account required · Statements processed locally · English and Chinese reports · CNY or USD ledgers

![A fictional studio received CNY 120,000 and paid CNY 72,000 in a month, leaving an operating cash surplus of CNY 48,000.](docs/media/en/cover.png)

## Explore a business before adding statements

Select **English** at the top right to switch from Chinese to English, or **Chinese** to switch back. The two report views are **Explore examples** and **My report**. In the examples, click **Another example** to switch businesses. An AI studio earns money building software agents and pays for model API calls. Friday Flowers sells bouquets and buys flowers and supplies. The report changes with the business.

![Random report illustration comparing an AI studio, Friday Flowers, and a study-abroad consultancy with different income sources and costs.](docs/media/en/random-reports.gif)

## Build a report from your own statements

Open **我的报告 (My report)**, add WeChat, Alipay, or bank statements, and review the entries as prompted. Add multiple files at once or append another month later. In the example below, two receipts totaling CNY 8,400 and a payment of CNY 1,200 leave a cash surplus of CNY 7,200. You can trace that total back to the entries.

![Statement import illustration showing three fictional statements, a review of dates, transaction directions and amounts, and the resulting cash report.](docs/media/en/statement-flow.gif)

- **Choose the period.** Select All months or the most recent 12, 6, 3, or 1 months with transactions. The filter skips missing months.
- **Find the underlying entries.** Click a monthly receipts or payments bar, or an income or cost category, to see the matching transactions. Check for a payment that appears on more than one platform when reviewing imports.
- **Add business records as needed.** Enter outstanding customer invoices to track receivables. Statements show cash movements. Complete income statements and balance sheets require supporting accounting records.

**Bank of America USD checking.** In **My report → Add statements**, select one or more original, text-based monthly PDFs. Before you confirm each import, Youshu checks the entries against the bank’s section totals and printed opening and closing balances. Importing the same PDF again skips the duplicate. Reports and exports show USD in either interface language.

Keep USD and CNY in separate ledgers. If you already use Youshu for CNY, open it in a separate browser profile for your USD statements.

For CNY ledgers, Youshu also accepts CSV, Excel and supported bank PDFs. Review the dates, amounts and directions in the import preview. For a scan that cannot be verified, use the bank’s Excel or CSV export.

## What if a customer pays a month late?

Move the **客户付款 (Customer payment timing)** slider to see how the timing affects your six-month cash forecast. Here, moving a CNY 20,000 receipt from November to December brings November’s projected closing balance down from CNY 70,000 to CNY 50,000. You can also adjust income and flexible spending to see when cash might run short.

![Cash forecast illustration showing a CNY 20,000 payment delayed by 30 days, a lower November closing balance, and recovery when the payment arrives in December.](docs/media/en/cash-forecast.gif)

## Open your first report

**[Download Youshu v0.4.0][download]** · ZIP, about 20 MB

1. **Download** `youshu-github-v0.4.0-bilingual.zip` to your computer using the link above.
2. **Extract the entire ZIP.** Double-click it on macOS or right-click and choose **Extract All** on Windows. Open the extracted `youshu-github-v0.4.0` folder and keep `assets/` and `templates/` alongside `index.html`.
3. **Double-click `index.html`.** Your browser opens the fictional report for Xingchen AI Applications Studio (星辰AI应用工作室). Select **Another example** to explore a different sample company at random. To start your own report, select **我的报告 (My report)** at the top right and add your statements.

![Getting started illustration showing the ZIP download, extraction, opening index.html, and the fictional studio report appearing in the browser.](docs/media/en/get-started.gif)

## Save and restore your ledger

The public package includes fictional examples and templates. Your browser processes imported statements and stores the ledger locally. Wait for **已保存 (Saved)** before closing, then reopen the app from the same location in the same browser to continue. Before switching computers or browsers, moving the app folder, or clearing browser data, download a ledger backup from **我的报告 → 管理账单 (My report → Manage statements)**.

On a new device, open Youshu and restore the JSON backup to continue editing your ledger. Export HTML or PDF to read or share a report. To remove the local ledger, select **清空我的报告 (Clear my report)** in Manage statements and confirm. Clearing the ledger is permanent. Your original files and downloaded backups stay on your computer.

[Workflow and calculation rules](docs/WORKFLOW.md) · [Evaluation](docs/EVALUATION.md) · [Deployment](DEPLOY.md) · [Commit history](Commit%20History.md) · [Earlier interface screenshots][screenshots]

Maintained by Yuchen Zhao. [MIT License](LICENSE) · [Third-party notices](assets/vendor/NOTICE.md)

---

# 有数

[English](#youshu)

![一家虚构工作室先看客户晚付 30 天时还剩多少现金，再从 9 月支出中找到一笔 7,800 元的支付宝付款。](docs/media/zh/youshu-demo.gif)

[下载中文演示片（MP4，17.5 秒）](docs/media/zh/youshu-demo.mp4?raw=1)

**把微信、支付宝和银行账单，变成个性化财务报告。专业还能看得懂！小微企业及OPC个人最佳搭子！**

v0.4.0　·　无需注册　·　账单在本机处理　·　中英文双语报告　·　支持人民币账本和美元账本

![有数示例报告，星辰AI应用工作室当月经营收款 12 万元、付款 7.2 万元，经营结余 4.8 万元。](docs/media/zh/cover.png)

## 手边没有账单，也能先试

在首页右上角点 **English** 切换到英文，点 **Chinese** 切回中文。首页有两个报告入口。**「随机体验」** 可以直接看虚构公司的经营情况，**「我的报告」** 用来导入自己的账单。点一下「再来一个」，就会换一家虚构公司。AI 工作室靠智能体开发收款，成本里有模型 API 调用费。「周五花铺」靠花束销售收款，主要支出则是鲜花与礼品材料。

![随机体验功能示意：依次查看 AI 工作室、周五花铺和留学咨询工作室的收支及主要业务项目。](docs/media/zh/random-reports.gif)

## 把自己的账单合起来看

进入 **「我的报告」**，添加微信、支付宝或银行账单，按提示核对并生成报告。可以一次添加多份，也可以下个月接着追加。比如两笔收款合计 8,400 元、一笔付款 1,200 元，报告就能把本期 7,200 元的收支结余和对应明细放在一起看。

![账单导入功能示意：添加三份虚构账单，核对日期、收支方向和金额，再查看本期收支。](docs/media/zh/statement-flow.gif)

- **回看某段时间。** 选「全部月份」覆盖整个账本，或选最近 12、6、3、1 个有数据的月份。中间缺月会跳过。
- **追到具体交易。** 点击月度收款柱、付款柱或收入与成本的构成项，查看对应明细。跨平台重复出现的同一笔付款也可以在核对时检查。
- **补齐经营资料。** 有未收回的客户款项，可以补录应收。账单反映现金收支，完整的利润表和资产负债表还需要相应的账务资料。

**美国银行（Bank of America）美元支票账户。** 在「我的报告 → 添加账单」选择银行下载的文字版月结单 PDF，可以一次选多份。有数会逐份核对交易分项合计，以及期初余额加收入、减支出后是否等于银行列出的期末余额。核对后即可确认导入。再次选择同一份 PDF 会跳过重复文件。无论选择中文还是英文，报告和导出的金额均标为美元。

美元和人民币分别建账。如果已有人民币账本，可在另一个浏览器个人资料中打开有数，单独保存美元账本。

人民币账本也支持 CSV、Excel 和适配的银行 PDF。请在导入预览中核对日期、收支方向和金额。扫描件难以核对时，可以改用银行导出的 Excel 或 CSV。

## 如果客户晚一个月付款？

在现金流沙盘里拖动 **「客户付款」**，就能比较不同回款时间下未来六个月的预计余额。动图里，一笔 2 万元回款从 11 月推迟到 12 月，11 月末手里的钱就从预计 7 万元降到 5 万元。你也可以调整「收入变化」和「弹性支出」，看看哪些月份需要提前留钱。

![现金沙盘功能示意：把一笔 2 万元回款推迟 30 天，11 月末预计余额减少 2 万元，12 月到账后回升。](docs/media/zh/cash-forecast.gif)

## 下载后怎么打开？

**[下载有数 v0.4.0][download]**　·　ZIP 约 20 MB

1. **下载。** 点击上方下载链接，把 `youshu-github-v0.4.0-bilingual.zip` 保存到电脑。
2. **解压。** 在 Mac 上双击 ZIP，在 Windows 上右键选择「全部解压缩」（Extract All）。打开解压后的 `youshu-github-v0.4.0` 文件夹，保留 `index.html`、`assets/` 和 `templates/` 的相对位置。
3. **双击 `index.html`。** 浏览器会先显示「星辰AI应用工作室」的虚构示例报告。点击「再来一个」，可以随机体验另一家公司的示例报告。点击右上角「我的报告」，就能添加自己的账单，开始制作自己的报告。

![启动流程示意：下载有数 ZIP，完整解压，打开文件夹并双击 index.html，浏览器显示星辰AI应用工作室示例报告。](docs/media/zh/get-started.gif)

## 账本保存在哪里？

公开的软件包附带虚构示例和模板。你导入的账单在浏览器中解析，账本保存在本机。看到 **「已保存」** 后，下次在同一浏览器、同一位置打开有数，就能继续使用账本。换电脑、换浏览器、移动软件文件夹或清理浏览器数据前，可到 **「我的报告 → 管理账单」** 下载账本备份。

换设备时，打开有数并恢复 JSON 备份，就能继续编辑账本。HTML 或 PDF 报告用于阅读和分享。需要移除本机记录时，在「管理账单」选择「清空我的报告」并确认。这个操作无法撤销，已下载的备份和原始文件仍保存在电脑上。

[工作流程与计算口径](docs/WORKFLOW.md) · [测试报告](docs/EVALUATION.md) · [部署说明](DEPLOY.md) · [提交历史](Commit%20History.md) · [历史界面截图][screenshots]

维护者为 Yuchen Zhao。项目使用 [MIT 许可证](LICENSE)，随包组件的许可见[第三方声明](assets/vendor/NOTICE.md)。

[download]: https://raw.githubusercontent.com/MirandaZhao/OPC-Auto-Finance-Report/main/youshu-github-v0.4.0-bilingual.zip
[screenshots]: https://github.com/MirandaZhao/OPC-Auto-Finance-Report/blob/0b01624b5bdd5a7957433d5b7bfac73c7359e509/README.md
